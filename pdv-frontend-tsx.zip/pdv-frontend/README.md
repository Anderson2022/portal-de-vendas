# PDV Suite — Front-end React + TypeScript

Projeto de demonstração visual com telas inspiradas nas referências fornecidas.

## Requisitos
- Node.js 20.19+ ou 22+
- npm

## Instalação e execução
```bash
npm install
npm run dev
```
Acesse o endereço exibido pelo Vite (normalmente http://localhost:5173).

## Produção
```bash
npm run build
npm run preview
```

## Funcionalidades demonstrativas
- Dashboard inicial com módulos PDV, mesas, delivery, serviços e supermercado.
- Lançamento e venda via cartão, seleção de produtos, leitor simulado, carrinho, desconto e modal de pagamento.
- Mesas com comandas e fechamento.
- Delivery com catálogo, pedidos e atualização de status.
- Serviços com profissionais, agenda e checkout.
- Cadastros, relatórios, financeiro e mapa de entregadores em modo demonstrativo.
- Atalhos de teclado, imagens otimizadas e layout responsivo.

## Observações
- É apenas o front-end: dados de exemplo em memória, sem integração com API, autenticação, banco de dados, gateway de pagamento, emissão fiscal, impressora ou rastreamento real.
- Para produção, integre os componentes com seu back-end Java/Spring Boot e APIs de pagamento, estoque e pedidos.
- Imagens dos cards e produtos ficam em `public/assets/`.
- A compilação final deve ser feita após `npm install` no seu ambiente; aqui a instalação de dependências não foi concluída.
